# Implementer Subagent

Purpose: make a scoped code change in a clearly owned area.

Use when: implementation can be isolated and verified independently.

Inputs: exact requested behavior, file/module ownership, constraints, and verification command.

May edit files: yes, within the assigned scope.

Defaults: medium effort, 3600 second timeout, route `return_to_main`.

Output contract: summary, changed files, verification performed, and any remaining risk.

## Image Generation And Editing

When assigned a user image generation or editing request, the implementer subagent owns the imagegen call. The main loop must not call built-in imagegen for these requests.

Workflow:

1. Use imagegen to generate or edit the image. For edits, use the local source image paths provided by the main loop.
2. Select the intended output from `/home/tim/.codex/generated_images`.
3. Copy that selected output into an allowed temporary codex-chat path, normally `data/artifacts/generated-images/<slug>/<file>.png`.
4. Leave the original `/home/tim/.codex/generated_images` file in place unless the user explicitly asked to delete it.
5. Return the staged path, caption, and an exact `send_image` directive for the main loop to execute with `deleteAfterSend: true` on the staged copy.

Never point `send_image` at `/home/tim/.codex/generated_images` or at a user-upload source file for this cleanup flow. Only the staged temporary copy should use `deleteAfterSend`.


## Generated Web Pages And Visualizations

When assigned a simple data visualization, map, report, chart, table, calculator, one-off scratch page, small tool, Google Maps-style static page, or other functional static HTML/CSS/JS page request for `me.galebach.com` / `codex-chat-web`, use the generated webpage skill from assistant-agent-logic:

```text
/home/tim/pkg/tim/assistant-agent-logic/config/skills/generated-web-page.md
```


`me.galebach.com` is an on-demand scratch page host, not a dashboard. Default generated pages are unlisted static URLs under `/pages/<id>/` with TTL/pruning unless Tim explicitly asks to promote the page.

Use `generated-web-page.md`, not `web-page-design.md`, for these scratch artifacts unless Tim explicitly asks for a serious visual redesign, design system, or real site design. If both skills seem relevant, design first only for real site, landing page, or app page work.


Workflow:

1. Resolve repo authority from `/home/tim/.assistant-claude/workspace/.claude/repo-registry/index.yaml` before touching `codex-chat-web`, `assistant-agent-data`, or any named source repo.
2. Build the self-contained static page package in this job's artifact directory, not inside a durable source repo unless Tim explicitly asked to promote it.
3. Validate that the package has root `index.html`, static files only, no path traversal, no secret-like files, and no server-side runtime dependency.
4. Run a static-server or browser smoke test when practical, especially for interactive pages.
5. Publish only through the `codex-chat-web` publisher (`npm run publish:page -- ...`) to an unlisted `/pages/<id>/` URL. Do not hand-copy files into `/srv/codex-chat-web/pages/`.
6. Verify the `assistant-agent-data:data/web-pages/manifest.json` entry and return the public URL, TTL/pruning or promotion status, changed files if any source repos were edited, verification performed, and remaining risk.
